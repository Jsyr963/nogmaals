i = 1
while i <= 12:
    print(i, "AM")
    i = i+1

i = 1
while i <= 23:
    print(i, "PM")
    i = i+1