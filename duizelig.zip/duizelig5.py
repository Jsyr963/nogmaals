invoer = ""
i = 0
while invoer != "quit":
    invoer = input("voer een getal in: ")
    i = i + 1
    print ("U heeft", i, "keer gebruik gemaakt van de input!" )